/******************************************************************************
STATEMENT 22:
22.	Write a program to input the name, age, height 
and gender of the student and prints the data of student on screen.
*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    
    string name, gender;
    int age;
    float height;

    cout << "Enter your name: ";
    getline(cin, name);

    cout << "Enter your age: ";
    cin >> age;

    cout << "Enter your height in meters: ";
    cin >> height;

    cout << "Enter your gender: ";
    cin >> gender;

    cout << "\n Student Details " << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << " years" << endl;
    cout << "Height: " << height << " meters" << endl;
    cout << "Gender: " << gender << endl;

    return 0;
}
