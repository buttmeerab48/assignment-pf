/******************************************************************************
STATEMENT 13:
Write a program using define directive to find the area of a circle. The formula to find the area of a circle is: 
	 	 	Area = 𝝅𝑹𝟐     𝐓𝐡𝐞 𝐯𝐚𝐥𝐮𝐞 𝐨𝐟 𝝅 𝒊𝒔 𝟑.𝟏𝟒𝟏𝟕 

*******************************************************************************/
#include <iostream>
using namespace std;
#define PI 3.1417
int main() {
    float radius, area;
    cout << "Enter the radius of the circle: ";
    cin >> radius;
    area = PI * radius * radius;
    cout << "The area of the circle is: " << area << endl;
    return 0;
}