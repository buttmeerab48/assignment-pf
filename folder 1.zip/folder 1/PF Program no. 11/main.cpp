/******************************************************************************
STATEMENT 10:
Write a program to find the volume of a cylinder by using 'const' qualifier. The formula to find the volume of a cylinder is: 
 	 	Volume = 𝝅𝑹𝟐𝐱𝐇     𝐓𝐡𝐞 𝐯𝐚𝐥𝐮𝐞 𝐨𝐟 𝝅 𝒊𝒔 𝟑. 𝟏𝟒𝟏𝟕 

*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
    const float PI = 3.1417;
    float radius, height, volume;
    cout << "Enter the radius of cylinder: ";
    cin >> radius;
    
    cout << "Enter the height of cylinder: ";
    cin >> height;
    
    volume = PI * radius * radius * height;
    cout << "Volume of cylinder = " << volume << endl;
    return 0;
}