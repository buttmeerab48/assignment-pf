#include <iostream>
using namespace std;
int main()
{
    int Num1, Num2, Sum, Product;
    cout<<"Enter first value"<<endl;
    cin>> Num1;
    cout<<"Enter second value"<<endl;
    cin>> Num2;
    Sum = Num1 + Num2;
    Product = Num1 * Num2;
    cout<<"The sum of Num1 and Num2 is:"<<Sum<<endl;
    cout<<"The product of Num1 and Num2 is:"<<Product<<endl;
    return 0;
}