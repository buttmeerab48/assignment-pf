/******************************************************************************
STATEMENT 20:
Write a program to print the output as given under by using escape
sequence.   
				C:\Windows>
				'P'     'A'     'K'
				"Pakistan"
****************************************************************************/
#include <iostream>
using namespace std;

 int main() {
    cout << "C:\\Windows>" << endl;
    cout << "'P'\t'A'\t'K'" << endl;
    cout << "\"Pakistan\"" << endl;

    return 0;
}
