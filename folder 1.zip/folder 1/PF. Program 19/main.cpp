/******************************************************************************
STATEMENT 19:
Write a program to assign your age in a variable and
find the age in months and days.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int ageYears = 18;

    int ageMonths = ageYears * 12;
    int ageDays = ageYears * 365;

    cout << "Age in years: " << ageYears << endl;
    cout << "Age in months: " << ageMonths << endl;
    cout << "Age in days: " << ageDays << endl;

    return 0;
}
