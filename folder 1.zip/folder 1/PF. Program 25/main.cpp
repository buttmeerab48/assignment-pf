/******************************************************************************
STATEMENT 25:
Write a program to input the values of three sides of a triangle and 
calculate its area using the formula:
	Area = √(s(s-a)(s-b)(s-c))  		where s = (a+b+c)/2
*******************************************************************************/
#include <iostream>
#include <cmath>  //for sqrt
using namespace std;

int main() {
    double a, b, c;

    cout << "Enter three sides of the triangle: ";
    cin >> a >> b >> c;

    double s = (a + b + c) / 2;
    double area = sqrt(s * (s - a) * (s - b) * (s - c));

    cout << "Area of the triangle: " << area << endl;

    return 0;
}
