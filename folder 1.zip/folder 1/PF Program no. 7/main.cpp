/******************************************************************************
STATEMENT 7:
Write a program to get the Roll No. of a student and marks obtained in three subject Programming Fundamentals, Introduction to Computing and Computer Graphics. Calculate the Total and Average. Each subject has a maximum of 100 marks.
*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int rollno, marksinPF, marksinIC, marksinCG, Total, average;
    cout<<"Enter Roll no:"<<endl;
    cin>>rollno;
    cout<<"Enter marks obtained in PF:"<<endl;
    cin>>marksinPF;
    cout<<"Enter marks obtained in IC:"<<endl;
    cin>>marksinIC;
    cout<<"Enter marks obtained in CG:"<<endl;
    cin>>marksinCG;
    Total=marksinPF+marksinIC+marksinCG;
    average=marksinPF+marksinIC+marksinCG;
    cout<<"Total marks:"<<Total<<endl;
    cout<<"Average marks:"<<average<<endl;
    return 0;
}