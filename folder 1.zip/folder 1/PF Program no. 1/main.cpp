/******************************************************************************
STATEMENT 1:
Write a program to assigned values to three values at the time of declaration. Print the assigned values.
*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;
int main()
{
  int Age = 20;
  string Name = "Hassan";
  char Grade = 'A';
    cout<<"Name=" <<Name <<endl;
    cout<<"Age=" <<Age <<endl;
    cout<<"Grade=" <<Grade <<endl;
     return 0;
}
