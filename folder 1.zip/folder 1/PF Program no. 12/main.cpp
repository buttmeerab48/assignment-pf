/******************************************************************************
STATEMENT 12:
Write a program to declare and initialize two variables of "int" type. Calculate the average of these values and print the result on screen.

*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
    int num1 = 10;
    int num2 = 20;
    float average = (num1 + num2) / 2.0;
    cout << "First number  = " << num1 << endl;
    cout << "Second number = " << num2 << endl;
    cout << "Average = " << average << endl;
    return 0;
}