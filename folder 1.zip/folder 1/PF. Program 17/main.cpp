/******************************************************************************
STATEMENT 17 :
17.	Write a program to separate the integral and fractional parts of a 15.58971
real number and print the result on screen.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    
    double number = 15.58971;
    
    int wholePart = (int) number;            
    double fractionPart = number - wholePart; 

    cout << "Integral part: " << wholePart << endl;
    cout << "Fractional part: " << fractionPart << endl;

    return 0;
}
