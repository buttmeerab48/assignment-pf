/******************************************************************************
STATEMENT 6:
Write a program to get age (in years) of a person. Calculate the age in months and print the age in months.
*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int Ageinyears, Ageinmonths;
    cout<<"Enter age in Years:"<<endl;
    cin>>Ageinyears;
    Ageinmonths = Ageinyears*12;
    cout<<"Age in Months:"<<Ageinmonths<<endl;
    return 0;
}