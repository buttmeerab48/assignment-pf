/******************************************************************************
STATEMENT 9:
Write a program to find the maximum number from four numbers. 
*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
    int a, b, c, d, max;
    cout << "Enter four numbers: ";
    cin >> a >> b >> c >> d;
    if (a >= b && a >= c && a >= d) {
        max = a;
    }
    else if (b >= a && b >= c && b >= d) {
        max = b;
    }
    else if (c >= a && c >= b && c >= d) {
        max = c;
    }
    else {
        max = d;
    }
    cout << "Maximum number is: " << max << endl;
    return 0;
}