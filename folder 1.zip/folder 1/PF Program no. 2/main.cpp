/******************************************************************************
STATEMENT 2:
Write a program to print a message "C language is a powerful programing language." on screen
*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    cout<<"C language is a powerful programming language"<<endl;
    return 0;
}