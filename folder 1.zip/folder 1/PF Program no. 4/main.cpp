/******************************************************************************
STATEMENT 4:
Write a program to assign the numeric value to a variable year. Calculate the number of months, and print on the screen.
*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int Years=4;
    int Months;
    Months = 4*12;
    cout<<"No. of months="<<Months<<endl;
    return 0;
}