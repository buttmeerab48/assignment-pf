/******************************************************************************
STATEMENT 10:
Write a program to convert 2.5 miles into kilometers and print the result on screen. (Hint: 1 mile = 1.609 kilometers). 
*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
    double miles = 2.5;
    double kilometers;
    
    kilometers = miles * 1.609;
    cout << miles << " miles = " << kilometers << " kilometers" << endl;
    return 0;
}