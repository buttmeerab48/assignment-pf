/******************************************************************************
STATEMENT 14:
 Write a program to convert millimeters into inches and print the result on screen. (Hint: 1 inch = 25.4 mm) 
*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
    float mm, inches;
    const float mmperinch = 25.4;
    cout << "Enter length in millimeters: ";
    cin >> mm;
    inches = mm / mmperinch;
    cout << mm << " millimeters is equal to " << inches << " inches." << endl;
    return 0;
}