/******************************************************************************
STATEMENT 27:
27.	Write a program to input time in hours, minutes and seconds. 
Convert time into seconds and print the result on screen.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int hours, minutes, seconds, totalSeconds;

    cout << "Enter hours: ";
    cin >> hours;
    cout << "Enter minutes: ";
    cin >> minutes;
    cout << "Enter seconds: ";
    cin >> seconds;

    totalSeconds = hours * 3600 + minutes * 60 + seconds;

    cout << "Total time in seconds: " << totalSeconds << endl;

    return 0;
}
