/******************************************************************************
STATEMENT 26:
Write a program to convert 12000 rupees into dollars (1 dollar = Rs. 60)

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    double rupees = 12000;   
    double rate = 60;        
    double dollars;
    
    dollars = rupees / rate;

    cout << "Rs. " << rupees << " is equal to $" << dollars << endl;

    return 0;
}
