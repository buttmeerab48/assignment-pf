/******************************************************************************
STATEMENT 24:
Write a program to input marks of five subjects of a student. 
Calculate the Total and Average marks. (Each subject has weight of 100 marks).

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    float marks[5]; 
    float total = 0, average;

    for(int i = 0; i < 5; i++) {
        cout << "Enter marks for subject " << (i + 1) << ": ";
        cin >> marks[i];
        total += marks[i]; 
    }

    average = total / 5;

    cout << "\nTotal Marks: " << total << endl;
    cout << "Average Marks: " << average << endl;

    return 0;
}
