/******************************************************************************
STATEMENT 18:
	Write a program to assign values to variables 'vi' and 't' an 
	compute the value of 's' by using the formula:
			S=vi*t+  1/2  〖at〗^2


*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    double vi, t, a, s;

    vi = 10;
    t = 5;
    a = 2;

    s = vi * t + 0.5 * a * t * t;  

    cout << "The distance traveled is: " << s << endl;

    return 0;
}
