/******************************************************************************
STATEMENT 3:
Write a program to assign two variables by assignment statement. Interchange the values and print the result on the screen.
*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int A, B, Temp;
    A=10;
    B=20;
    Temp=A;
    A=B;
    B=Temp;
    cout<<"The value of A is:"<<A<<endl;
    cout<<"The value of B is:"<<B<<endl;
    return 0;
}