/******************************************************************************
STATEMENT 23:
Write a program to input the radius of a circle and calculate
area & circumstance of the circle.
		Formula for Area of a circle = πR^2
		Formula for Circumference of a circle = 2πR
*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    const float PI = 3.14159;  
    float radius, area, circumference;

    cout << "Enter the radius of the circle: ";
    cin >> radius;

    area = PI * radius * radius;
    circumference = 2 * PI * radius;
    
    cout << "\nArea of the circle: " << area << endl;
    cout << "Circumference of the circle: " << circumference << endl;

    return 0;
}
