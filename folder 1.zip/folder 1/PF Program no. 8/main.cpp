/******************************************************************************
STATEMENT 8:
Write a program to get temperature in Fahrenheit. Convert the temperature to Celsius degrees by using the formula.
C = 5/9(f - 32)
*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int tempinC, tempinF;
    cout<<"Temperature in Fahrenheit:"<<endl;
    cin>>tempinF;
    tempinC= 5/9 *(tempinF - 32);
    cout<<"Temperature in Celcius:"<<tempinC<<endl;
    return 0;
}