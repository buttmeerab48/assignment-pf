/******************************************************************************
STATMENT 30:
Write a program to test whether a given integer is odd or even using
simple 'if' structure
*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter an integer: ";
    cin >> n;

    if (n % 2 == 0) {
        cout << n << " is even." << endl;
    } else {
        cout << n << " is odd." << endl;
    }

    return 0;
}
